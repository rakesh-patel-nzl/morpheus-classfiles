## Url on which Morpheus will be reachable.
## For more details on configuring appliance_url see:
## https://docs.morpheusdata.com
appliance_url 'https://lab-app-3.megadata.com'
elasticsearch['es_hosts'] = {'172.30.10.161' => 9200, '172.30.10.162' => 9200, '172.30.10.163' => 9200}
elasticsearch['node_name'] = '172.30.10.163'
elasticsearch['host'] = '0.0.0.0'
rabbitmq['host'] = '0.0.0.0'
rabbitmq['nodename'] = 'rabbit@lab-app-3'
mysql['enable'] = false
mysql['host'] = {'127.0.0.1' => 6446}
mysql['morpheus_db'] = 'morpheus'
mysql['morpheus_db_user'] = 'morpheus'
mysql['morpheus_password'] = 'Password123?'
mysql['max_active'] = 150
user['uid'] = 899
user['gid'] = 899
node.default['morpheus_solo']['local_user']['uid'] = 898
node.default['morpheus_solo']['local_user']['gid'] = 898
elasticsearch['uid'] = 896
elasticsearch['gid'] = 896
rabbitmq['uid'] = 895
rabbitmq['gid'] = 895
guacd['uid'] = 894